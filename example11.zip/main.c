/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include<math.h>

int main()
{
    int ad;
    float  kot ,deta ,alpha ,beta ,gamma;
    ad=3200;
    kot=0.0056;
    deta=alpha*beta/gamma+3.2*2/5;
    printf("deta = %f\n",deta);


    return 0;
}
