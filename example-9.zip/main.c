/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.
*******************************************************************************/

//paper size A0 has Dimension 1189 X 841 mm .Each subsequent size A(n)is Defined as A(n-1) .writ  a programm  to calculatev an print paer sizes A0,A1,A2,...A8

#include <stdio.h>

int main()
{
   int a0ht,a0wd;
   int a1ht,a1wd,a2ht,a2wd,a3ht,a3wd,a4ht,a4wd;
  int a5ht,a5wd,a6ht,a6wd,a7ht,a7wd,a8ht,a8wd;
  a0ht=1189;a0wd=841;
  
  //printing the size from A0to A8

  printf("Size ofA0 paper Ht=%d,Width=%d\n",a0ht,a0wd);
  a1ht=a0wd;a1wd=a0ht/2;
   printf("Size of A1 paper Ht=%d,Width=%d\n",a1ht,a1wd);
  a2ht=a1wd;a2wd=a1ht/2;
    printf("Size ofA0 paper Ht=%d,Width=%d\n",a0ht,a0wd);
  a3ht=a2wd;a3wd=a2ht/2;
   printf("Size of A1 paper Ht=%d,Width=%d\n",a1ht,a1wd);
  a4ht=a3wd;a4wd=a3ht/2;
    printf("Size ofA0 paper Ht=%d,Width=%d\n",a0ht,a0wd);
  a5ht=a4wd;a5wd=a4ht/2;
   printf("Size of A1 paper Ht=%d,Width=%d\n",a1ht,a1wd);
  a6ht=a5wd;a6wd=a5ht/2;
    printf("Size ofA0 paper Ht=%d,Width=%d\n",a0ht,a0wd);
  a7ht=a6wd;a7wd=a6ht/2;
   printf("Size of A1 paper Ht=%d,Width=%d\n",a1ht,a1wd);
  a8ht=a7wd;a7wd=a7ht/2;
    return 0;
}
